<?= $this->extend('_Layout/_template/_gis/templateGis'); ?>





<?= $this->section('content'); ?>


<!-- ISI CONTENT -->


<section id="" class="">
    <div class="container">


        <div class="map" id="map"></div>
        <div style="background-color: whitesmoke;" class="infoPos" id="infoPos">Text</div>


    </div>
</section>


<!-- END ISI CONTENT -->


<?= $this->endSection(); ?>